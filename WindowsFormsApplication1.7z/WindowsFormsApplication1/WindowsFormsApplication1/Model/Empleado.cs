﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1.Model
{
    class Empleado
    {
        public Empleado()
        {
            Id = 0;
            Nombre = string.Empty;
            Apellido = string.Empty;
            Salario = 0;
        }
        //Constructor
        public Empleado(int id, string nombre, string apellido, double salario)
        {
            Id = id;
            Nombre = nombre;
            Apellido = apellido;
            Salario = salario;
        }
        //Propiedades
        //"prop" +tab +tab
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public double Salario { get; set; }
    }
}
