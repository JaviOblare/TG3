﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using WindowsFormsApplication1.Model;

namespace WindowsFormsApplication1.Controler
{
    class EmpleadoControler
    {
        Empleado objEmpleado;
        SqlConnection objSqlConnection;
        SqlCommand objSqlCommand;
        SqlDataReader ObjSqlDataReader;

        //contrsutcor
        public EmpleadoControler(Empleado empleado)
        {
            objEmpleado = empleado;
        }


        void Ejecutar (String Procedimiento)
        {///realizamos la conexion de la BD
            objSqlConnection = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = c:\users\javi_\documents\visual studio 2015\Projects\WindowsFormsApplication1\WindowsFormsApplication1\MiDB.mdf; Integrated Security = True; Connect Timeout = 30");
            objSqlCommand = new SqlCommand();
            objSqlCommand.Connection= objSqlConnection;
            objSqlCommand.CommandText = Procedimiento;
            objSqlCommand.CommandType = CommandType.StoredProcedure;
        }



    }
}
