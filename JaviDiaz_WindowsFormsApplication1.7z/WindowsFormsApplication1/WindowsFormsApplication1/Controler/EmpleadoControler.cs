﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using WindowsFormsApplication1.Model;

namespace WindowsFormsApplication1.Controler
{
    class EmpleadoControler
    {
        Empleado objEmpleado;
        SqlConnection objSqlConnection;
        SqlCommand objSqlCommand;
        SqlDataReader ObjSqlDataReader;

        //contrsutcor
        public EmpleadoControler(Empleado empleado)
        {
            objEmpleado = empleado;
        }


        void Ejecutar(String Procedimiento)
        {///realizamos la conexion de la BD
            objSqlConnection = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = c:\users\javi_\documents\visual studio 2015\Projects\WindowsFormsApplication1\WindowsFormsApplication1\MiDB.mdf; Integrated Security = True; Connect Timeout = 30");
            objSqlCommand = new SqlCommand();
            objSqlCommand.Connection = objSqlConnection;
            objSqlCommand.CommandText = Procedimiento;
            objSqlCommand.CommandType = CommandType.StoredProcedure;
        }

        public bool Consulta()
        {
            bool estado = false;
            Ejecutar("EjecutarConsulta");
         //   objSqlCommand.Parameters.Add("@Id", SqlDbType.Int, 10);
            objSqlCommand.Parameters.Add("@Nombre", SqlDbType.VarChar, 10);
            objSqlCommand.Parameters.Add("@Apellido", SqlDbType.VarChar, 10);
            objSqlCommand.Parameters.Add("@Salario", SqlDbType.VarChar, 10);
            
            try
            {
                objSqlConnection.Open();
           //     objSqlCommand.Parameters["@Id"].Value = objEmpleado.Id;
                objSqlCommand.Parameters["@Nombre"].Value = objEmpleado.Nombre;
                objSqlCommand.Parameters["@Apellido"].Value = objEmpleado.Apellido;
                objSqlCommand.Parameters["@Salario"].Value = objEmpleado.Salario;

                ObjSqlDataReader = objSqlCommand.ExecuteReader();
                if (ObjSqlDataReader.Read())
                {
                    estado = true;
                }
            }

            catch (SqlException ex)
            {
                throw new Exception(ex.Message);

            }
            finally
            {
                objSqlConnection.Close();
            }
            return estado;

        }


        public bool Consulta2()
        {
            bool estado = false;
            Ejecutar("Crear");

            objSqlCommand.Parameters.Add("@Id",SqlDbType.VarChar,10);
            objSqlCommand.Parameters.Add("@Nombre", SqlDbType.VarChar, 10);
            objSqlCommand.Parameters.Add("@Apellido", SqlDbType.VarChar, 10);
            objSqlCommand.Parameters.Add("@Salario", SqlDbType.VarChar, 10);
            try
            {
                objSqlConnection.Open();
                objSqlCommand.Parameters["@Id"].Value = objEmpleado.Id;
                objSqlCommand.Parameters["@Nombre"].Value = objEmpleado.Nombre;
                objSqlCommand.Parameters["@Apellido"].Value = objEmpleado.Apellido;
                objSqlCommand.Parameters["@Salario"].Value = objEmpleado.Salario;

                ObjSqlDataReader = objSqlCommand.ExecuteReader();
                if (ObjSqlDataReader.Read())
                {
                    estado = true;
                }
            }

            catch (SqlException ex)
            {
                throw new Exception(ex.Message);

            }
            finally
            {
                objSqlConnection.Close();
            }
            return estado;

        }
    }
    }

