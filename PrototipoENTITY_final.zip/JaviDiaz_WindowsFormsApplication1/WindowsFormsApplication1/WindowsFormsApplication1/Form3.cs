﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1.Model;
using WindowsFormsApplication1.Controler;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
      
        private void button1_Click(object sender, EventArgs e)
        {
              Form2 frm = new Form2();
               frm.Show();
               this.Hide();
            
           
        }

        private void Form3_Load(object sender, EventArgs e)
        {
           // this.empleadoTableAdapter1.Update();
            // TODO: This line of code loads data into the 'miDBDataSet2.Empleado' table. You can move, or remove it, as needed.
            this.empleadoTableAdapter1.Fill(this.miDBDataSet2.Empleado);

        }
    }
}
