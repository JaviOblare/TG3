﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1.Model;
using WindowsFormsApplication1.Controler;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

      /*  private void button1_Click(object sender, EventArgs e)
        {
            Empleado objEmpleado = new Empleado();
            objEmpleado.Nombre = textBox1.Text;
            objEmpleado.Apellido = textBox2.Text;
            objEmpleado.Salario = textBox3.Text;
            EmpleadoControler objCrEmpleado = new EmpleadoControler(objEmpleado);
            if (objCrEmpleado.Consulta())
            {
                MessageBox.Show("Existe, se llama "+textBox1.Text+" "+textBox2.Text+" y cobra "+textBox3.Text+" €.");

            }
            else
                MessageBox.Show("No existe ningun empleado con este nombre, apellido y salario");

        }*/
        /*
        private void button2_Click(object sender, EventArgs e)
        {
            Empleado objEmpleado = new Empleado();
           objEmpleado.Id = int.Parse(textBox4.Text);
            objEmpleado.Nombre = textBox1.Text;
            objEmpleado.Apellido = textBox2.Text;
            objEmpleado.Salario = textBox3.Text;
            EmpleadoControler objCrEmpleado = new EmpleadoControler(objEmpleado);
            if (objCrEmpleado.Consulta2())
            {
                MessageBox.Show("Añadido " + textBox1.Text + " " + textBox2.Text + " y cobra " + textBox3.Text + " €.");

            }
            else
                MessageBox.Show("Ya esta registrado este empleado ");
        }
        */
        private void button1_Click_1(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Empleado objEmpleado = new Empleado();
            objEmpleado.Id = int.Parse(textBox4.Text);
            objEmpleado.Nombre = textBox1.Text;
            objEmpleado.Apellido = textBox2.Text;
            objEmpleado.Salario = textBox3.Text;
            EmpleadoControler objCrEmpleado = new EmpleadoControler(objEmpleado);
            if (objCrEmpleado.Consulta2())
            {
                MessageBox.Show("Añadido " + textBox1.Text + " " + textBox2.Text + " y cobra " + textBox3.Text + " €.");

            }
            else
                MessageBox.Show("Ya esta registrado este empleado ");
        }
    }
}
